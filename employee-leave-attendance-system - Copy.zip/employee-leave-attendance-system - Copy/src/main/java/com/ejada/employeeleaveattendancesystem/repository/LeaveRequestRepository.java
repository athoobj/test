package com.ejada.employeeleaveattendancesystem.repository;

import com.ejada.employeeleaveattendancesystem.entity.LeaveRequest;
import com.ejada.employeeleaveattendancesystem.entity.LeaveStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface LeaveRequestRepository
        extends JpaRepository<LeaveRequest, Long> {

    List<LeaveRequest> findByEmployeeId(Long employeeId);

    List<LeaveRequest> findByStatus(LeaveStatus status);

    long countByStatus(LeaveStatus status);

    List<LeaveRequest>
    findByEmployeeIdAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
            Long employeeId,
            LocalDate endDate,
            LocalDate startDate
    );

    List<LeaveRequest> findByEmployeeIdAndStatus(
            Long employeeId,
            LeaveStatus status
    );

    @Query("""
            SELECT lr
            FROM LeaveRequest lr
            WHERE
                (:status IS NULL OR lr.status = :status)
                AND (:employeeId IS NULL OR lr.employee.id = :employeeId)
                AND (
                    :keyword IS NULL
                    OR :keyword = ''
                    OR LOWER(lr.employee.fullName) LIKE LOWER(CONCAT('%', :keyword, '%'))
                    OR LOWER(lr.reason) LIKE LOWER(CONCAT('%', :keyword, '%'))
                )
            """)
    Page<LeaveRequest> searchLeaveRequests(
            @Param("keyword") String keyword,
            @Param("status") LeaveStatus status,
            @Param("employeeId") Long employeeId,
            Pageable pageable
    );
}