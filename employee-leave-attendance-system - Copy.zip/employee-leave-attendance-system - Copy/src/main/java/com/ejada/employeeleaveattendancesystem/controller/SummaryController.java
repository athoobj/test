package com.ejada.employeeleaveattendancesystem.controller;

import com.ejada.employeeleaveattendancesystem.service.SummaryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/summary")
public class SummaryController {

    private final SummaryService summaryService;

    public SummaryController(SummaryService summaryService) {
        this.summaryService = summaryService;
    }

    @GetMapping
    public Map<String, Long> getSystemSummary() {
        return summaryService.getSystemSummary();
    }
}