package com.ejada.employeeleaveattendancesystem.controller;

import com.ejada.employeeleaveattendancesystem.entity.Attendance;
import com.ejada.employeeleaveattendancesystem.service.AttendanceService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;

    public AttendanceController(
            AttendanceService attendanceService) {

        this.attendanceService = attendanceService;
    }

    @GetMapping
    public List<Attendance> getAllAttendanceRecords(
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {

        return attendanceService.getAllAttendanceRecords(
                sortBy,
                direction
        );
    }

    @GetMapping("/{id}")
    public Attendance getAttendanceById(
            @PathVariable Long id) {

        return attendanceService.getAttendanceById(id);
    }

    @GetMapping("/employee/{employeeId}")
    public List<Attendance> getAttendanceByEmployee(
            @PathVariable Long employeeId) {

        return attendanceService
                .getAttendanceByEmployee(employeeId);
    }

    @GetMapping("/date")
    public List<Attendance> getAttendanceByDate(
            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date) {

        return attendanceService
                .getAttendanceByDate(date);
    }

    @PostMapping("/check-in/{employeeId}")
    public Attendance checkIn(
            @PathVariable Long employeeId) {

        return attendanceService.checkIn(employeeId);
    }

    @PutMapping("/check-out/{employeeId}")
    public Attendance checkOut(
            @PathVariable Long employeeId) {

        return attendanceService.checkOut(employeeId);
    }

    @PostMapping("/absent/{employeeId}")
    public Attendance markAbsent(
            @PathVariable Long employeeId,
            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date) {

        return attendanceService
                .markAbsent(employeeId, date);
    }

    @PutMapping("/{id}")
    public Attendance updateAttendance(
            @PathVariable Long id,
            @Valid @RequestBody Attendance attendance) {

        return attendanceService
                .updateAttendance(id, attendance);
    }

    @PatchMapping("/{id}")
    public Attendance patchAttendance(
            @PathVariable Long id,
            @RequestBody Attendance attendance) {

        return attendanceService
                .patchAttendance(id, attendance);
    }

    @DeleteMapping("/{id}")
    public String deleteAttendance(
            @PathVariable Long id) {

        attendanceService.deleteAttendance(id);

        return "Attendance record deleted successfully";
    }
}