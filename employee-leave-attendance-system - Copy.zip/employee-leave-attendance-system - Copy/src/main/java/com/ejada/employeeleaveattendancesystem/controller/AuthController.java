package com.ejada.employeeleaveattendancesystem.controller;

import com.ejada.employeeleaveattendancesystem.dto.LoginRequest;
import com.ejada.employeeleaveattendancesystem.dto.LoginResponse;
import com.ejada.employeeleaveattendancesystem.service.AuthService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public LoginResponse login(
            @RequestBody LoginRequest request) {

        return authService.login(
                request.username(),
                request.password()
        );
    }
}