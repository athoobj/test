package com.ejada.employeeleaveattendancesystem.service.interfaces;

import com.ejada.employeeleaveattendancesystem.entity.Employee;

import java.util.List;
import java.util.Map;

public interface EmployeeServiceInterface {

    List<Employee> getAllEmployees(String sortBy, String direction);

    Employee getEmployeeById(Long id);

    Employee createEmployee(Employee employee);

    Employee updateEmployee(Long id, Employee employee);

    void deleteEmployee(Long id);

    Employee partiallyUpdateEmployee(Long id, Map<String, Object> updates);
}