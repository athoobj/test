package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.entity.Employee;
import com.ejada.employeeleaveattendancesystem.service.interfaces.EmployeeServiceInterface;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("alternativeEmployeeService")
public class AlternativeEmployeeService implements EmployeeServiceInterface {

    private final EmployeeService employeeService;

    public AlternativeEmployeeService(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public List<Employee> getAllEmployees(
            String sortBy,
            String direction) {

        return employeeService.getAllEmployees(sortBy, direction);
    }

    @Override
    public Employee getEmployeeById(Long id) {

        return employeeService.getEmployeeById(id);
    }

    @Override
    public Employee createEmployee(Employee employee) {

        return employeeService.createEmployee(employee);
    }

    @Override
    public Employee updateEmployee(
            Long id,
            Employee employee) {

        return employeeService.updateEmployee(id, employee);
    }

    @Override
    public void deleteEmployee(Long id) {

        employeeService.deleteEmployee(id);
    }

    @Override
    public Employee partiallyUpdateEmployee(
            Long id,
            Map<String, Object> updates) {

        return employeeService.partiallyUpdateEmployee(id, updates);
    }
}