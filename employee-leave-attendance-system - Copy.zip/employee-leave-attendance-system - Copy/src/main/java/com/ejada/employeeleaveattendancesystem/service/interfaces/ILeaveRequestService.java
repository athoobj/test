package com.ejada.employeeleaveattendancesystem.service.interfaces;

import com.ejada.employeeleaveattendancesystem.entity.LeaveRequest;
import com.ejada.employeeleaveattendancesystem.entity.LeaveStatus;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Map;

public interface ILeaveRequestService {

    List<LeaveRequest> getAllLeaveRequests(
            String sortBy,
            String direction
    );

    Page<LeaveRequest> searchLeaveRequests(
            String keyword,
            LeaveStatus status,
            Long employeeId,
            int page,
            int size,
            String sortBy,
            String direction
    );

    LeaveRequest getLeaveRequestById(Long id);

    List<LeaveRequest> getRequestsByEmployee(
            Long employeeId
    );

    List<LeaveRequest> getRequestsByStatus(
            LeaveStatus status
    );

    LeaveRequest createLeaveRequest(
            Long employeeId,
            Long leaveTypeId,
            LeaveRequest leaveRequest
    );

    LeaveRequest updateLeaveRequest(
            Long id,
            Long employeeId,
            Long leaveTypeId,
            LeaveRequest leaveRequest
    );

    LeaveRequest partiallyUpdateLeaveRequest(
            Long id,
            Map<String, Object> updates
    );

    LeaveRequest approveLeaveRequest(Long id);

    LeaveRequest rejectLeaveRequest(Long id);

    LeaveRequest cancelLeaveRequest(Long id);

    void deleteLeaveRequest(Long id);
}