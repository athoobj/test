package com.ejada.employeeleaveattendancesystem.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import javax.sql.DataSource;
import java.util.List;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public JdbcUserDetailsManager userDetailsService(DataSource dataSource) {
        return new JdbcUserDetailsManager(dataSource);
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration configuration)
            throws Exception {

        return configuration.getAuthenticationManager();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration = new CorsConfiguration();

        configuration.setAllowedOrigins(
                List.of("http://localhost:4200")
        );

        configuration.setAllowedMethods(
                List.of(
                        "GET",
                        "POST",
                        "PUT",
                        "PATCH",
                        "DELETE",
                        "OPTIONS"
                )
        );

        configuration.setAllowedHeaders(List.of("*"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration(
                "/**",
                configuration
        );

        return source;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http
                .cors(Customizer.withDefaults())

                .csrf(csrf -> csrf.disable())

                .authorizeHttpRequests(auth -> auth

                        // Public URLs
                        .requestMatchers(
                                "/swagger-ui/**",
                                "/swagger-ui.html",
                                "/v3/api-docs/**",
                                "/actuator/health",
                                "/actuator/info",
                                "/app-info",
                                "/css/**",
                                "/auth/login",
                                "/login",
                                "/error"
                        ).permitAll()

                        // =========================
                        // LEAVE REQUEST WORKFLOW
                        // =========================

                        // HR can approve requests
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/leave-requests/*/approve"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // HR can reject requests
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/leave-requests/*/reject"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Employee can cancel a request
                        // HR/Admin also allowed
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/leave-requests/*/cancel"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Only HR/Admin can delete
                        .requestMatchers(
                                HttpMethod.DELETE,
                                "/leave-requests/**"
                        )
                        .hasAnyRole( "ADMIN")

                        // Employee can submit leave request
                        .requestMatchers(
                                HttpMethod.POST,
                                "/leave-requests"
                        )
                        .hasAnyRole("EMPLOYEE", "HR", "ADMIN")

                        // Updating leave requests
                        .requestMatchers(
                                HttpMethod.PUT,
                                "/leave-requests/*"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        .requestMatchers(
                                HttpMethod.PATCH,
                                "/leave-requests/*"
                        )
                        .hasAnyRole("HR", "ADMIN")

                        // Both roles can view leave requests
                        .requestMatchers(
                                HttpMethod.GET,
                                "/leave-requests/**"
                        )
                        .hasAnyRole("EMPLOYEE", "HR", "ADMIN")

                        // =========================
                        // ATTENDANCE
                        // =========================

                        .requestMatchers("/attendance/**")
                        .hasAnyRole("EMPLOYEE", "HR", "ADMIN")

                        // =========================
                        // EMPLOYEES
                        // =========================

                        .requestMatchers("/employees/**")
                        .hasAnyRole("HR", "ADMIN")

                        // =========================
                        // LEAVE TYPES
                        // =========================

                        .requestMatchers("/leave-types/**")
                        .hasAnyRole("HR", "ADMIN")

                        // =========================
                        // DASHBOARD / REPORTS
                        // =========================

                        .requestMatchers("/summary/**")
                        .hasAnyRole("HR", "ADMIN")

                        .requestMatchers("/dashboard/**")
                        .hasAnyRole("EMPLOYEE", "HR", "ADMIN")

                        // Anything else
                        .anyRequest()
                        .authenticated()
                )

                .httpBasic(Customizer.withDefaults())

                .formLogin(Customizer.withDefaults());

        return http.build();
    }
}