package com.ejada.employeeleaveattendancesystem.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import javax.sql.DataSource;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public JdbcUserDetailsManager userDetailsService(DataSource dataSource) {
        return new JdbcUserDetailsManager(dataSource);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http
                .csrf(csrf -> csrf.disable())

                .authorizeHttpRequests(auth -> auth

                        // Public URLs
                        .requestMatchers(
                                "/swagger-ui/**",
                                "/swagger-ui.html",
                                "/v3/api-docs/**",
                                "/actuator/health",
                                "/actuator/info",
                                "/app-info",
                                "/css/**",
                                "/login",
                                "/error"
                        ).permitAll()

                        // Employee Management
                        .requestMatchers("/employees/**")
                        .hasAnyRole("HR", "ADMIN")

                        // Leave Type Management
                        .requestMatchers("/leave-types/**")
                        .hasAnyRole("HR", "ADMIN")

                        // Attendance Management
                        .requestMatchers("/attendance/**")
                        .hasAnyRole("EMPLOYEE", "HR", "ADMIN")

                        // Leave Request Management
                        .requestMatchers("/leave-requests/**")
                        .hasAnyRole("EMPLOYEE", "HR", "ADMIN")

                        // Summary
                        .requestMatchers("/summary/**")
                        .hasAnyRole("HR", "ADMIN")

                        // Any other URL requires authentication
                        .anyRequest()
                        .authenticated()
                )

                .httpBasic(Customizer.withDefaults())
                .formLogin(Customizer.withDefaults());

        return http.build();
    }
}