package com.ejada.employeeleaveattendancesystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeLeaveAttendanceSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeLeaveAttendanceSystemApplication.class, args);
    }

}
