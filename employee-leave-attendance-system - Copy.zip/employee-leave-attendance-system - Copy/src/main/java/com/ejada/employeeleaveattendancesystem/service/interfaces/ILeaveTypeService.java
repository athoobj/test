package com.ejada.employeeleaveattendancesystem.service.interfaces;

import com.ejada.employeeleaveattendancesystem.entity.LeaveType;

import java.util.List;
import java.util.Map;

public interface ILeaveTypeService {

    List<LeaveType> getAllLeaveTypes(
            String sortBy,
            String direction
    );

    LeaveType getLeaveTypeById(Long id);

    LeaveType createLeaveType(LeaveType leaveType);

    LeaveType updateLeaveType(
            Long id,
            LeaveType updatedLeaveType
    );

    LeaveType partiallyUpdateLeaveType(
            Long id,
            Map<String, Object> updates
    );

    void deleteLeaveType(Long id);
}