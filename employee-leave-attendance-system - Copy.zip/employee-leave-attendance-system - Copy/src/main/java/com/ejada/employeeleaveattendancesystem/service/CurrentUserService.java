package com.ejada.employeeleaveattendancesystem.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class CurrentUserService {

    private final JdbcTemplate jdbcTemplate;

    public CurrentUserService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public String getCurrentUsername() {

        Authentication authentication =
                SecurityContextHolder
                        .getContext()
                        .getAuthentication();

        return authentication.getName();
    }

    public boolean isEmployee() {

        Authentication authentication =
                SecurityContextHolder
                        .getContext()
                        .getAuthentication();

        return authentication.getAuthorities()
                .stream()
                .anyMatch(authority ->
                        authority.getAuthority()
                                .equals("ROLE_EMPLOYEE")
                );
    }

    public Long getCurrentEmployeeId() {

        String username = getCurrentUsername();

        return jdbcTemplate.query(
                """
                SELECT employee_id
                FROM users
                WHERE username = ?
                """,
                resultSet -> {

                    if (resultSet.next()) {

                        long employeeId =
                                resultSet.getLong("employee_id");

                        return resultSet.wasNull()
                                ? null
                                : employeeId;
                    }

                    return null;
                },
                username
        );
    }
}