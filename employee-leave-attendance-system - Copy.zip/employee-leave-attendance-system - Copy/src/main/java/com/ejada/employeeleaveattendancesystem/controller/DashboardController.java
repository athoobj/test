package com.ejada.employeeleaveattendancesystem.controller;

import com.ejada.employeeleaveattendancesystem.service.SummaryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    private final SummaryService summaryService;

    public DashboardController(
            SummaryService summaryService) {

        this.summaryService = summaryService;
    }

    @GetMapping("/personal")
    public Map<String, Long> getPersonalSummary() {

        return summaryService.getPersonalSummary();
    }
}