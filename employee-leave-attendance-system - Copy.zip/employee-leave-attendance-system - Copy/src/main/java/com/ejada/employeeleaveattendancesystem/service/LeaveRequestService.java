package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.entity.Employee;
import com.ejada.employeeleaveattendancesystem.entity.LeaveRequest;
import com.ejada.employeeleaveattendancesystem.entity.LeaveStatus;
import com.ejada.employeeleaveattendancesystem.entity.LeaveType;
import com.ejada.employeeleaveattendancesystem.repository.LeaveRequestRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.ejada.employeeleaveattendancesystem.service.interfaces.ILeaveRequestService;
import com.ejada.employeeleaveattendancesystem.exception.ResourceNotFoundException;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class LeaveRequestService implements ILeaveRequestService {

    private final LeaveRequestRepository leaveRequestRepository;
    private final EmployeeService employeeService;
    private final LeaveTypeService leaveTypeService;

    public LeaveRequestService(
            LeaveRequestRepository leaveRequestRepository,
            EmployeeService employeeService,
            LeaveTypeService leaveTypeService) {

        this.leaveRequestRepository = leaveRequestRepository;
        this.employeeService = employeeService;
        this.leaveTypeService = leaveTypeService;
    }

    public List<LeaveRequest> getAllLeaveRequests(
            String sortBy,
            String direction) {

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        return leaveRequestRepository.findAll(sort);
    }

    public LeaveRequest getLeaveRequestById(Long id) {
        return leaveRequestRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Leave request not found with id: " + id
                        )
                );
    }

    public List<LeaveRequest> getRequestsByEmployee(Long employeeId) {

        employeeService.getEmployeeById(employeeId);

        return leaveRequestRepository.findByEmployeeId(employeeId);
    }

    public List<LeaveRequest> getRequestsByStatus(
            LeaveStatus status) {

        return leaveRequestRepository.findByStatus(status);
    }

    public LeaveRequest createLeaveRequest(
            Long employeeId,
            Long leaveTypeId,
            LeaveRequest leaveRequest) {

        Employee employee =
                employeeService.getEmployeeById(employeeId);

        LeaveType leaveType =
                leaveTypeService.getLeaveTypeById(leaveTypeId);

        validateDates(
                leaveRequest.getStartDate(),
                leaveRequest.getEndDate()
        );

        validateNoOverlap(
                employeeId,
                leaveRequest.getStartDate(),
                leaveRequest.getEndDate(),
                null
        );

        leaveRequest.setEmployee(employee);
        leaveRequest.setLeaveType(leaveType);
        leaveRequest.setStatus(LeaveStatus.PENDING);

        return leaveRequestRepository.save(leaveRequest);
    }

    public LeaveRequest updateLeaveRequest(
            Long id,
            Long employeeId,
            Long leaveTypeId,
            LeaveRequest updatedRequest) {

        LeaveRequest existingRequest =
                getLeaveRequestById(id);

        Employee employee =
                employeeService.getEmployeeById(employeeId);

        LeaveType leaveType =
                leaveTypeService.getLeaveTypeById(leaveTypeId);

        validateDates(
                updatedRequest.getStartDate(),
                updatedRequest.getEndDate()
        );

        validateNoOverlap(
                employeeId,
                updatedRequest.getStartDate(),
                updatedRequest.getEndDate(),
                id
        );

        existingRequest.setEmployee(employee);
        existingRequest.setLeaveType(leaveType);
        existingRequest.setStartDate(
                updatedRequest.getStartDate()
        );
        existingRequest.setEndDate(
                updatedRequest.getEndDate()
        );
        existingRequest.setReason(
                updatedRequest.getReason()
        );

        if (updatedRequest.getStatus() != null) {
            existingRequest.setStatus(
                    updatedRequest.getStatus()
            );
        }

        return leaveRequestRepository.save(existingRequest);
    }

    public LeaveRequest partiallyUpdateLeaveRequest(
            Long id,
            Map<String, Object> updates) {

        LeaveRequest existingRequest =
                getLeaveRequestById(id);

        if (updates.containsKey("employeeId")) {

            Long employeeId = Long.valueOf(
                    updates.get("employeeId").toString()
            );

            Employee employee =
                    employeeService.getEmployeeById(employeeId);

            existingRequest.setEmployee(employee);
        }

        if (updates.containsKey("leaveTypeId")) {

            Long leaveTypeId = Long.valueOf(
                    updates.get("leaveTypeId").toString()
            );

            LeaveType leaveType =
                    leaveTypeService.getLeaveTypeById(leaveTypeId);

            existingRequest.setLeaveType(leaveType);
        }

        if (updates.containsKey("startDate")) {

            existingRequest.setStartDate(
                    LocalDate.parse(
                            updates.get("startDate").toString()
                    )
            );
        }

        if (updates.containsKey("endDate")) {

            existingRequest.setEndDate(
                    LocalDate.parse(
                            updates.get("endDate").toString()
                    )
            );
        }

        if (updates.containsKey("reason")) {

            existingRequest.setReason(
                    updates.get("reason") == null
                            ? null
                            : updates.get("reason").toString()
            );
        }

        if (updates.containsKey("status")) {

            existingRequest.setStatus(
                    LeaveStatus.valueOf(
                            updates.get("status")
                                    .toString()
                                    .toUpperCase()
                    )
            );
        }

        validateDates(
                existingRequest.getStartDate(),
                existingRequest.getEndDate()
        );

        validateNoOverlap(
                existingRequest.getEmployee().getId(),
                existingRequest.getStartDate(),
                existingRequest.getEndDate(),
                id
        );

        return leaveRequestRepository.save(existingRequest);
    }

    public LeaveRequest approveLeaveRequest(Long id) {

        LeaveRequest leaveRequest =
                getLeaveRequestById(id);

        leaveRequest.setStatus(LeaveStatus.APPROVED);

        return leaveRequestRepository.save(leaveRequest);
    }

    public LeaveRequest rejectLeaveRequest(Long id) {

        LeaveRequest leaveRequest =
                getLeaveRequestById(id);

        leaveRequest.setStatus(LeaveStatus.REJECTED);

        return leaveRequestRepository.save(leaveRequest);
    }

    public void deleteLeaveRequest(Long id) {

        LeaveRequest leaveRequest =
                getLeaveRequestById(id);

        leaveRequestRepository.delete(leaveRequest);
    }

    private void validateDates(
            LocalDate startDate,
            LocalDate endDate) {

        if (startDate == null || endDate == null) {
            throw new IllegalArgumentException(
                    "Start date and end date are required"
            );
        }

        if (endDate.isBefore(startDate)) {
            throw new IllegalArgumentException(
                    "End date cannot be before start date"
            );
        }
    }

    private void validateNoOverlap(
            Long employeeId,
            LocalDate startDate,
            LocalDate endDate,
            Long currentRequestId) {

        List<LeaveRequest> overlappingRequests =
                leaveRequestRepository
                        .findByEmployeeIdAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
                                employeeId,
                                endDate,
                                startDate
                        );

        boolean overlapExists =
                overlappingRequests.stream()
                        .anyMatch(request ->
                                currentRequestId == null
                                        || !request.getId()
                                        .equals(currentRequestId)
                        );

        if (overlapExists) {
            throw new IllegalArgumentException(
                    "Leave request overlaps with an existing leave request"
            );
        }
    }
}