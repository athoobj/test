package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.entity.Employee;
import com.ejada.employeeleaveattendancesystem.entity.LeaveRequest;
import com.ejada.employeeleaveattendancesystem.entity.LeaveStatus;
import com.ejada.employeeleaveattendancesystem.entity.LeaveType;
import com.ejada.employeeleaveattendancesystem.exception.BusinessConflictException;
import com.ejada.employeeleaveattendancesystem.exception.ResourceNotFoundException;
import com.ejada.employeeleaveattendancesystem.repository.LeaveRequestRepository;
import com.ejada.employeeleaveattendancesystem.service.interfaces.ILeaveRequestService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class LeaveRequestService implements ILeaveRequestService {

    private final LeaveRequestRepository leaveRequestRepository;
    private final EmployeeService employeeService;
    private final LeaveTypeService leaveTypeService;
    private final CurrentUserService currentUserService;

    public LeaveRequestService(
            LeaveRequestRepository leaveRequestRepository,
            EmployeeService employeeService,
            LeaveTypeService leaveTypeService,
            CurrentUserService currentUserService) {

        this.leaveRequestRepository = leaveRequestRepository;
        this.employeeService = employeeService;
        this.leaveTypeService = leaveTypeService;
        this.currentUserService = currentUserService;
    }

    public List<LeaveRequest> getAllLeaveRequests(
            String sortBy,
            String direction) {

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        if (currentUserService.isEmployee()) {

            Long employeeId = getLoggedInEmployeeId();

            return leaveRequestRepository
                    .findByEmployeeId(employeeId);
        }

        return leaveRequestRepository.findAll(sort);
    }

    public Page<LeaveRequest> searchLeaveRequests(
            String keyword,
            LeaveStatus status,
            Long employeeId,
            int page,
            int size,
            String sortBy,
            String direction) {

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable =
                PageRequest.of(page, size, sort);

        // Employee must see only own leave requests
        if (currentUserService.isEmployee()) {
            employeeId = getLoggedInEmployeeId();
        }

        return leaveRequestRepository.searchLeaveRequests(
                keyword,
                status,
                employeeId,
                pageable
        );
    }

    public LeaveRequest getLeaveRequestById(Long id) {

        LeaveRequest leaveRequest =
                leaveRequestRepository.findById(id)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Leave request not found with id: " + id
                                )
                        );

        validateEmployeeOwnership(
                leaveRequest.getEmployee().getId()
        );

        return leaveRequest;
    }

    public List<LeaveRequest> getRequestsByEmployee(
            Long employeeId) {

        validateEmployeeOwnership(employeeId);

        employeeService.getEmployeeById(employeeId);

        return leaveRequestRepository
                .findByEmployeeId(employeeId);
    }

    public List<LeaveRequest> getRequestsByStatus(
            LeaveStatus status) {

        if (currentUserService.isEmployee()) {

            Long employeeId = getLoggedInEmployeeId();

            return leaveRequestRepository
                    .findByEmployeeIdAndStatus(
                            employeeId,
                            status
                    );
        }

        return leaveRequestRepository
                .findByStatus(status);
    }

    public LeaveRequest createLeaveRequest(
            Long employeeId,
            Long leaveTypeId,
            LeaveRequest leaveRequest) {

        // Employee can submit only for own account
        validateEmployeeOwnership(employeeId);

        Employee employee =
                employeeService.getEmployeeById(employeeId);

        LeaveType leaveType =
                leaveTypeService.getLeaveTypeById(leaveTypeId);

        validateDates(
                leaveRequest.getStartDate(),
                leaveRequest.getEndDate()
        );

        validateNoOverlap(
                employeeId,
                leaveRequest.getStartDate(),
                leaveRequest.getEndDate(),
                null
        );

        leaveRequest.setEmployee(employee);
        leaveRequest.setLeaveType(leaveType);
        leaveRequest.setStatus(LeaveStatus.PENDING);

        return leaveRequestRepository.save(leaveRequest);
    }

    public LeaveRequest updateLeaveRequest(
            Long id,
            Long employeeId,
            Long leaveTypeId,
            LeaveRequest updatedRequest) {

        LeaveRequest existingRequest =
                getLeaveRequestById(id);

        Employee employee =
                employeeService.getEmployeeById(employeeId);

        LeaveType leaveType =
                leaveTypeService.getLeaveTypeById(leaveTypeId);

        validateDates(
                updatedRequest.getStartDate(),
                updatedRequest.getEndDate()
        );

        validateNoOverlap(
                employeeId,
                updatedRequest.getStartDate(),
                updatedRequest.getEndDate(),
                id
        );

        existingRequest.setEmployee(employee);
        existingRequest.setLeaveType(leaveType);
        existingRequest.setStartDate(
                updatedRequest.getStartDate()
        );
        existingRequest.setEndDate(
                updatedRequest.getEndDate()
        );
        existingRequest.setReason(
                updatedRequest.getReason()
        );

        if (updatedRequest.getStatus() != null) {
            existingRequest.setStatus(
                    updatedRequest.getStatus()
            );
        }

        return leaveRequestRepository.save(existingRequest);
    }

    public LeaveRequest partiallyUpdateLeaveRequest(
            Long id,
            Map<String, Object> updates) {

        LeaveRequest existingRequest =
                getLeaveRequestById(id);

        if (updates.containsKey("employeeId")) {

            Long employeeId = Long.valueOf(
                    updates.get("employeeId").toString()
            );

            Employee employee =
                    employeeService.getEmployeeById(employeeId);

            existingRequest.setEmployee(employee);
        }

        if (updates.containsKey("leaveTypeId")) {

            Long leaveTypeId = Long.valueOf(
                    updates.get("leaveTypeId").toString()
            );

            LeaveType leaveType =
                    leaveTypeService.getLeaveTypeById(leaveTypeId);

            existingRequest.setLeaveType(leaveType);
        }

        if (updates.containsKey("startDate")) {

            existingRequest.setStartDate(
                    LocalDate.parse(
                            updates.get("startDate").toString()
                    )
            );
        }

        if (updates.containsKey("endDate")) {

            existingRequest.setEndDate(
                    LocalDate.parse(
                            updates.get("endDate").toString()
                    )
            );
        }

        if (updates.containsKey("reason")) {

            existingRequest.setReason(
                    updates.get("reason") == null
                            ? null
                            : updates.get("reason").toString()
            );
        }

        if (updates.containsKey("status")) {

            existingRequest.setStatus(
                    LeaveStatus.valueOf(
                            updates.get("status")
                                    .toString()
                                    .toUpperCase()
                    )
            );
        }

        validateDates(
                existingRequest.getStartDate(),
                existingRequest.getEndDate()
        );

        validateNoOverlap(
                existingRequest.getEmployee().getId(),
                existingRequest.getStartDate(),
                existingRequest.getEndDate(),
                id
        );

        return leaveRequestRepository.save(existingRequest);
    }

    public LeaveRequest approveLeaveRequest(Long id) {

        LeaveRequest leaveRequest =
                getLeaveRequestById(id);

        if (leaveRequest.getStatus() != LeaveStatus.PENDING) {
            throw new BusinessConflictException(
                    "Only pending leave requests can be approved"
            );
        }

        leaveRequest.setStatus(LeaveStatus.APPROVED);

        return leaveRequestRepository.save(leaveRequest);
    }

    public LeaveRequest rejectLeaveRequest(Long id) {

        LeaveRequest leaveRequest =
                getLeaveRequestById(id);

        if (leaveRequest.getStatus() != LeaveStatus.PENDING) {
            throw new BusinessConflictException(
                    "Only pending leave requests can be rejected"
            );
        }

        leaveRequest.setStatus(LeaveStatus.REJECTED);

        return leaveRequestRepository.save(leaveRequest);
    }

    public LeaveRequest cancelLeaveRequest(Long id) {

        LeaveRequest leaveRequest =
                getLeaveRequestById(id);

        // If logged-in user is EMPLOYEE,
        // getLeaveRequestById already verifies ownership.

        if (leaveRequest.getStatus() != LeaveStatus.PENDING) {
            throw new BusinessConflictException(
                    "Only pending leave requests can be cancelled"
            );
        }

        leaveRequest.setStatus(LeaveStatus.CANCELLED);

        return leaveRequestRepository.save(leaveRequest);
    }

    public void deleteLeaveRequest(Long id) {

        LeaveRequest leaveRequest =
                getLeaveRequestById(id);

        leaveRequestRepository.delete(leaveRequest);
    }

    private Long getLoggedInEmployeeId() {

        Long employeeId =
                currentUserService.getCurrentEmployeeId();

        if (employeeId == null) {
            throw new AccessDeniedException(
                    "Employee account is not linked to an employee record"
            );
        }

        return employeeId;
    }

    private void validateEmployeeOwnership(
            Long employeeId) {

        if (!currentUserService.isEmployee()) {
            return;
        }

        Long currentEmployeeId =
                getLoggedInEmployeeId();

        if (!currentEmployeeId.equals(employeeId)) {
            throw new AccessDeniedException(
                    "You can access only your own leave requests"
            );
        }
    }

    private void validateDates(
            LocalDate startDate,
            LocalDate endDate) {

        if (startDate == null || endDate == null) {
            throw new IllegalArgumentException(
                    "Start date and end date are required"
            );
        }

        if (endDate.isBefore(startDate)) {
            throw new IllegalArgumentException(
                    "End date cannot be before start date"
            );
        }
    }

    private void validateNoOverlap(
            Long employeeId,
            LocalDate startDate,
            LocalDate endDate,
            Long currentRequestId) {

        List<LeaveRequest> overlappingRequests =
                leaveRequestRepository
                        .findByEmployeeIdAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
                                employeeId,
                                endDate,
                                startDate
                        );

        boolean overlapExists =
                overlappingRequests.stream()
                        .anyMatch(request ->
                                currentRequestId == null
                                        || !request.getId()
                                        .equals(currentRequestId)
                        );

        if (overlapExists) {
            throw new IllegalArgumentException(
                    "Leave request overlaps with an existing leave request"
            );
        }
    }
}