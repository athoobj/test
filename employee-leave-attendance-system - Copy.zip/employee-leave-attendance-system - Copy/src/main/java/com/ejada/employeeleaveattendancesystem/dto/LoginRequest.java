package com.ejada.employeeleaveattendancesystem.dto;
public record LoginRequest(
        String username,
        String password
) {

}