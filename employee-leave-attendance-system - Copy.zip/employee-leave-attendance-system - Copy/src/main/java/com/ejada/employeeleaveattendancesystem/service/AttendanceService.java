package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.entity.Attendance;
import com.ejada.employeeleaveattendancesystem.entity.AttendanceStatus;
import com.ejada.employeeleaveattendancesystem.entity.Employee;
import com.ejada.employeeleaveattendancesystem.exception.ResourceNotFoundException;
import com.ejada.employeeleaveattendancesystem.repository.AttendanceRepository;
import com.ejada.employeeleaveattendancesystem.service.interfaces.IAttendanceService;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
public class AttendanceService implements IAttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final EmployeeService employeeService;

    public AttendanceService(
            AttendanceRepository attendanceRepository,
            EmployeeService employeeService) {

        this.attendanceRepository = attendanceRepository;
        this.employeeService = employeeService;
    }

    public List<Attendance> getAllAttendanceRecords(
            String sortBy,
            String direction) {

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        return attendanceRepository.findAll(sort);
    }

    public Attendance getAttendanceById(Long id) {
        return attendanceRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Attendance record not found with id: " + id
                        )
                );
    }

    public List<Attendance> getAttendanceByEmployee(Long employeeId) {

        employeeService.getEmployeeById(employeeId);

        return attendanceRepository.findByEmployeeId(employeeId);
    }

    public List<Attendance> getAttendanceByDate(LocalDate date) {
        return attendanceRepository.findByAttendanceDate(date);
    }

    public Attendance checkIn(Long employeeId) {

        Employee employee =
                employeeService.getEmployeeById(employeeId);

        LocalDate today = LocalDate.now();

        if (attendanceRepository
                .existsByEmployeeIdAndAttendanceDate(
                        employeeId,
                        today
                )) {

            throw new IllegalArgumentException(
                    "Attendance already recorded for this employee today"
            );
        }

        Attendance attendance = Attendance.builder()
                .employee(employee)
                .attendanceDate(today)
                .checkInTime(LocalTime.now())
                .status(AttendanceStatus.PRESENT)
                .build();

        return attendanceRepository.save(attendance);
    }

    public Attendance checkOut(Long employeeId) {

        LocalDate today = LocalDate.now();

        Attendance attendance =
                attendanceRepository
                        .findByEmployeeIdAndAttendanceDate(
                                employeeId,
                                today
                        )
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "No check-in record found for this employee today"
                                )
                        );

        if (attendance.getCheckOutTime() != null) {
            throw new IllegalArgumentException(
                    "Employee has already checked out today"
            );
        }

        attendance.setCheckOutTime(LocalTime.now());

        validateAttendanceTimes(attendance);

        return attendanceRepository.save(attendance);
    }

    public Attendance markAbsent(
            Long employeeId,
            LocalDate date) {

        Employee employee =
                employeeService.getEmployeeById(employeeId);

        if (attendanceRepository
                .existsByEmployeeIdAndAttendanceDate(
                        employeeId,
                        date
                )) {

            throw new IllegalArgumentException(
                    "Attendance already recorded for this employee on this date"
            );
        }

        Attendance attendance = Attendance.builder()
                .employee(employee)
                .attendanceDate(date)
                .status(AttendanceStatus.ABSENT)
                .build();

        return attendanceRepository.save(attendance);
    }

    public Attendance updateAttendance(
            Long id,
            Attendance updatedAttendance) {

        Attendance attendance =
                getAttendanceById(id);

        validateAttendanceTimes(updatedAttendance);

        attendance.setAttendanceDate(
                updatedAttendance.getAttendanceDate()
        );

        attendance.setCheckInTime(
                updatedAttendance.getCheckInTime()
        );

        attendance.setCheckOutTime(
                updatedAttendance.getCheckOutTime()
        );

        attendance.setStatus(
                updatedAttendance.getStatus()
        );

        attendance.setNotes(
                updatedAttendance.getNotes()
        );

        return attendanceRepository.save(attendance);
    }

    public Attendance patchAttendance(
            Long id,
            Attendance updatedAttendance) {

        Attendance attendance =
                getAttendanceById(id);

        if (updatedAttendance.getAttendanceDate() != null) {
            attendance.setAttendanceDate(
                    updatedAttendance.getAttendanceDate()
            );
        }

        if (updatedAttendance.getCheckInTime() != null) {
            attendance.setCheckInTime(
                    updatedAttendance.getCheckInTime()
            );
        }

        if (updatedAttendance.getCheckOutTime() != null) {
            attendance.setCheckOutTime(
                    updatedAttendance.getCheckOutTime()
            );
        }

        if (updatedAttendance.getStatus() != null) {
            attendance.setStatus(
                    updatedAttendance.getStatus()
            );
        }

        if (updatedAttendance.getNotes() != null) {
            attendance.setNotes(
                    updatedAttendance.getNotes()
            );
        }

        validateAttendanceTimes(attendance);

        return attendanceRepository.save(attendance);
    }

    public void deleteAttendance(Long id) {

        Attendance attendance =
                getAttendanceById(id);

        attendanceRepository.delete(attendance);
    }

    private void validateAttendanceTimes(
            Attendance attendance) {

        if (attendance.getCheckInTime() != null
                && attendance.getCheckOutTime() != null
                && attendance.getCheckOutTime()
                .isBefore(attendance.getCheckInTime())) {

            throw new IllegalArgumentException(
                    "Check-out time cannot be before check-in time"
            );
        }
    }
}