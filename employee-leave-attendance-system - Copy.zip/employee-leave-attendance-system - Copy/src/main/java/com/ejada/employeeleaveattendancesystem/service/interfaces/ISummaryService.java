package com.ejada.employeeleaveattendancesystem.service.interfaces;

import java.util.Map;

public interface ISummaryService {

    Map<String, Long> getSystemSummary();

    Map<String, Long> getLeaveStatusReport();

    Map<String, Long> getAttendanceByEmployeeReport();

    Map<String, Long> getPersonalSummary();
}