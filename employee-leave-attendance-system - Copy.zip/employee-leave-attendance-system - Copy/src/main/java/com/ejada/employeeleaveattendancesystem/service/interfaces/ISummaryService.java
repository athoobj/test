package com.ejada.employeeleaveattendancesystem.service.interfaces;

import java.util.Map;

public interface ISummaryService {

    Map<String, Long> getSystemSummary();
}