package com.ejada.employeeleaveattendancesystem.service.interfaces;

import com.ejada.employeeleaveattendancesystem.entity.Attendance;

import java.time.LocalDate;
import java.util.List;

public interface IAttendanceService {

    List<Attendance> getAllAttendanceRecords(
            String sortBy,
            String direction
    );

    Attendance getAttendanceById(Long id);

    List<Attendance> getAttendanceByEmployee(Long employeeId);

    List<Attendance> getAttendanceByDate(LocalDate date);

    Attendance checkIn(Long employeeId);

    Attendance checkOut(Long employeeId);

    Attendance markAbsent(
            Long employeeId,
            LocalDate date
    );

    Attendance updateAttendance(
            Long id,
            Attendance updatedAttendance
    );

    Attendance patchAttendance(
            Long id,
            Attendance updatedAttendance
    );

    void deleteAttendance(Long id);
}