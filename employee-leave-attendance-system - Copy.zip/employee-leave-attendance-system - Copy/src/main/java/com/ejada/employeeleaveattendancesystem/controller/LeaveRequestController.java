package com.ejada.employeeleaveattendancesystem.controller;

import com.ejada.employeeleaveattendancesystem.entity.LeaveRequest;
import com.ejada.employeeleaveattendancesystem.entity.LeaveStatus;
import com.ejada.employeeleaveattendancesystem.service.LeaveRequestService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/leave-requests")
public class LeaveRequestController {

    private final LeaveRequestService leaveRequestService;

    public LeaveRequestController(
            LeaveRequestService leaveRequestService) {

        this.leaveRequestService = leaveRequestService;
    }

    @GetMapping
    public List<LeaveRequest> getAllLeaveRequests(
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {

        return leaveRequestService.getAllLeaveRequests(
                sortBy,
                direction
        );
    }

    @GetMapping("/{id}")
    public LeaveRequest getLeaveRequestById(
            @PathVariable Long id) {

        return leaveRequestService.getLeaveRequestById(id);
    }

    @GetMapping("/employee/{employeeId}")
    public List<LeaveRequest> getRequestsByEmployee(
            @PathVariable Long employeeId) {

        return leaveRequestService
                .getRequestsByEmployee(employeeId);
    }

    @GetMapping("/status/{status}")
    public List<LeaveRequest> getRequestsByStatus(
            @PathVariable LeaveStatus status) {

        return leaveRequestService
                .getRequestsByStatus(status);
    }

    @PostMapping
    public LeaveRequest createLeaveRequest(
            @RequestParam Long employeeId,
            @RequestParam Long leaveTypeId,
            @Valid @RequestBody LeaveRequest leaveRequest) {

        return leaveRequestService.createLeaveRequest(
                employeeId,
                leaveTypeId,
                leaveRequest
        );
    }

    @PutMapping("/{id}")
    public LeaveRequest updateLeaveRequest(
            @PathVariable Long id,
            @RequestParam Long employeeId,
            @RequestParam Long leaveTypeId,
            @Valid @RequestBody LeaveRequest leaveRequest) {

        return leaveRequestService.updateLeaveRequest(
                id,
                employeeId,
                leaveTypeId,
                leaveRequest
        );
    }

    @PatchMapping("/{id}")
    public LeaveRequest partiallyUpdateLeaveRequest(
            @PathVariable Long id,
            @RequestBody Map<String, Object> updates) {

        return leaveRequestService
                .partiallyUpdateLeaveRequest(id, updates);
    }

    @PutMapping("/{id}/approve")
    public LeaveRequest approveLeaveRequest(
            @PathVariable Long id) {

        return leaveRequestService
                .approveLeaveRequest(id);
    }

    @PutMapping("/{id}/reject")
    public LeaveRequest rejectLeaveRequest(
            @PathVariable Long id) {

        return leaveRequestService
                .rejectLeaveRequest(id);
    }

    @DeleteMapping("/{id}")
    public String deleteLeaveRequest(
            @PathVariable Long id) {

        leaveRequestService.deleteLeaveRequest(id);

        return "Leave request deleted successfully";
    }
}