package com.ejada.employeeleaveattendancesystem.entity;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
}