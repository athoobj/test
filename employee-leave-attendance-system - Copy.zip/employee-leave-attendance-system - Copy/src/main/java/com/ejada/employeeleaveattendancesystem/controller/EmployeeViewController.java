package com.ejada.employeeleaveattendancesystem.controller;

import com.ejada.employeeleaveattendancesystem.entity.Employee;
import com.ejada.employeeleaveattendancesystem.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class EmployeeViewController {

    private final EmployeeService employeeService;

    public EmployeeViewController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/employee-list")
    public String employeeList(Model model) {

        model.addAttribute(
                "employees",
                employeeService.getAllEmployees("id", "asc")
        );

        return "employees";
    }

    @GetMapping("/employee-form")
    public String employeeForm(Model model) {

        model.addAttribute("employee", new Employee());

        return "employee-form";
    }

    @PostMapping("/employee-save")
    public String saveEmployee(
            @Valid @ModelAttribute("employee") Employee employee,
            BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            return "employee-form";
        }

        employeeService.createEmployee(employee);

        return "redirect:/employee-list";
    }
}