package com.ejada.employeeleaveattendancesystem.service;

import com.ejada.employeeleaveattendancesystem.entity.LeaveStatus;
import com.ejada.employeeleaveattendancesystem.repository.AttendanceRepository;
import com.ejada.employeeleaveattendancesystem.repository.EmployeeRepository;
import com.ejada.employeeleaveattendancesystem.repository.LeaveRequestRepository;
import org.springframework.stereotype.Service;
import com.ejada.employeeleaveattendancesystem.service.interfaces.ISummaryService;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class SummaryService implements ISummaryService {

    private final EmployeeRepository employeeRepository;
    private final LeaveRequestRepository leaveRequestRepository;
    private final AttendanceRepository attendanceRepository;

    public SummaryService(
            EmployeeRepository employeeRepository,
            LeaveRequestRepository leaveRequestRepository,
            AttendanceRepository attendanceRepository) {

        this.employeeRepository = employeeRepository;
        this.leaveRequestRepository = leaveRequestRepository;
        this.attendanceRepository = attendanceRepository;
    }
    @Override
    public Map<String, Long> getSystemSummary() {

        Map<String, Long> summary = new LinkedHashMap<>();

        summary.put(
                "totalEmployees",
                employeeRepository.count()
        );

        summary.put(
                "totalLeaveRequests",
                leaveRequestRepository.count()
        );

        summary.put(
                "pendingLeaveRequests",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.PENDING
                )
        );

        summary.put(
                "approvedLeaveRequests",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.APPROVED
                )
        );

        summary.put(
                "rejectedLeaveRequests",
                leaveRequestRepository.countByStatus(
                        LeaveStatus.REJECTED
                )
        );

        summary.put(
                "totalAttendanceRecords",
                attendanceRepository.count()
        );

        return summary;
    }
}