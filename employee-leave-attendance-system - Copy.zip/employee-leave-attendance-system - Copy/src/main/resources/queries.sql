-- ============================================
-- Employee Leave & Attendance System
-- SQL Queries
-- ============================================

-- =========================
-- EMPLOYEES CRUD
-- =========================

-- INSERT
INSERT INTO employees(employee_number, full_name, email, department, active)
VALUES ('EMP005','Mohammed Salem','mohammed@company.com','IT',true);

-- SELECT
SELECT * FROM employees;

-- UPDATE
UPDATE employees
SET department='Human Resources'
WHERE employee_number='EMP005';

-- DELETE
DELETE FROM employees
WHERE employee_number='EMP005';


-- =========================
-- LEAVE TYPES CRUD
-- =========================

INSERT INTO leave_types(name,description,maximum_days,active)
VALUES ('Study Leave','For study purposes',10,true);

SELECT * FROM leave_types;

UPDATE leave_types
SET maximum_days=15
WHERE name='Study Leave';

DELETE FROM leave_types
WHERE name='Study Leave';


-- =========================
-- LEAVE REQUESTS CRUD
-- =========================

INSERT INTO leave_requests
(employee_id, leave_type_id, start_date, end_date, reason, status)
VALUES
    (1, 2, '2026-08-01', '2026-08-03', 'Medical Checkup', 'PENDING');

SELECT * FROM leave_requests;

UPDATE leave_requests
SET status='APPROVED'
WHERE id=1;

DELETE FROM leave_requests
WHERE id=3;


-- =========================
-- ATTENDANCE CRUD
-- =========================

INSERT INTO attendance_records
(employee_id, attendance_date, check_in_time, check_out_time, status, notes)
VALUES
    (1, '2026-07-25', '08:00:00', '16:00:00', 'PRESENT', 'Normal working day');

SELECT * FROM attendance_records;

UPDATE attendance_records
SET status='LATE'
WHERE id=2;

DELETE FROM attendance_records
WHERE id=4;


-- =========================
-- INNER JOIN
-- =========================

SELECT
    e.full_name,
    lt.name AS leave_type,
    lr.start_date,
    lr.end_date,
    lr.status
FROM leave_requests lr
         JOIN employees e
              ON lr.employee_id=e.id
         JOIN leave_types lt
              ON lr.leave_type_id=lt.id;


-- =========================
-- LEFT JOIN
-- =========================

SELECT
    e.full_name,
    a.attendance_date,
    a.status
FROM employees e
         LEFT JOIN attendance_records a
                   ON e.id=a.employee_id;


-- =========================
-- AGGREGATE FUNCTIONS
-- =========================

SELECT COUNT(*) AS total_employees
FROM employees;

SELECT COUNT(*) AS total_leave_requests
FROM leave_requests;

SELECT MAX(maximum_days)
FROM leave_types;

SELECT MIN(maximum_days)
FROM leave_types;

SELECT AVG(maximum_days)
FROM leave_types;


-- =========================
-- GROUP BY
-- =========================

SELECT
    department,
    COUNT(*) AS employees_count
FROM employees
GROUP BY department;


-- =========================
-- ORDER BY
-- =========================

SELECT *
FROM employees
ORDER BY full_name ASC;


-- =========================
-- VIEW
-- =========================

CREATE OR REPLACE VIEW employee_leave_summary AS
SELECT
    e.full_name,
    lt.name AS leave_type,
    lr.start_date,
    lr.end_date,
    lr.status
FROM employees e
         JOIN leave_requests lr
              ON e.id=lr.employee_id
         JOIN leave_types lt
              ON lt.id=lr.leave_type_id;

SELECT * FROM employee_leave_summary;