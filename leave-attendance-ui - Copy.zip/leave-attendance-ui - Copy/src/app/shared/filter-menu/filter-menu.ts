import { Component, EventEmitter, Input, Output } from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { LeaveStatus } from '../../models/leave-request';

import { Employee } from '../../models/employee';

@Component({
  selector: 'app-filter-menu',
  imports: [CommonModule, FormsModule],
  templateUrl: './filter-menu.html',
  styleUrl: './filter-menu.css',
})
export class FilterMenu {
  @Input()
  status: LeaveStatus | '' = '';

  @Input()
  employeeId: number | null = null;

  @Input()
  employees: Employee[] = [];

  @Input()
  showEmployeeFilter = false;

  @Output()
  statusChange = new EventEmitter<LeaveStatus | ''>();

  @Output()
  employeeChange = new EventEmitter<number | null>();

  onStatusChange(): void {
    this.statusChange.emit(this.status);
  }

  onEmployeeChange(): void {
    this.employeeChange.emit(this.employeeId);
  }
}
