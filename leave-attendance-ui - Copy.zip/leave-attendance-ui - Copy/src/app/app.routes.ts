import { Routes } from '@angular/router';

import { Login } from './pages/login/login';
import { Dashboard } from './pages/dashboard/dashboard';
import { LeaveRequests } from './pages/leave-requests/leave-requests';
import { LeaveRequestDetail } from './pages/leave-request-detail/leave-request-detail';
import { LeaveRequestForm } from './pages/leave-request-form/leave-request-form';
import { LeaveRequestWorkflow } from './pages/leave-request-workflow/leave-request-workflow';
import { Attendance } from './pages/attendance/attendance';
import { Employees } from './pages/employees/employees';
import { LeaveTypes } from './pages/leave-types/leave-types';
import { AccessDenied } from './pages/access-denied/access-denied';
import { PageNotFound } from './pages/page-not-found/page-not-found';

import { authGuard } from './guards/auth-guard';
import { roleGuard } from './guards/role-guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  },

  {
    path: 'login',
    component: Login,
  },

  {
    path: 'dashboard',
    component: Dashboard,
    canActivate: [authGuard],
  },

  {
    path: 'leave-requests',
    component: LeaveRequests,
    canActivate: [authGuard],
  },

  {
    path: 'leave-requests/search/:keyword',
    component: LeaveRequests,
    canActivate: [authGuard],
  },

  {
    path: 'leave-requests/filter/:value',
    component: LeaveRequests,
    canActivate: [authGuard],
  },

  {
    path: 'leave-requests/detail/:id',
    component: LeaveRequestDetail,
    canActivate: [authGuard],
  },

  {
    path: 'leave-requests/add',
    component: LeaveRequestForm,
    canActivate: [authGuard],
  },

  {
    path: 'leave-requests/edit/:id',
    component: LeaveRequestForm,
    canActivate: [authGuard, roleGuard],
    data: {
      roles: ['HR', 'ADMIN'],
    },
  },

  {
    path: 'leave-requests/:id/workflow',
    component: LeaveRequestWorkflow,
    canActivate: [authGuard],
  },

  {
    path: 'attendance',
    component: Attendance,
    canActivate: [authGuard],
  },

  {
    path: 'employees',
    component: Employees,
    canActivate: [authGuard, roleGuard],
    data: {
      roles: ['HR', 'ADMIN'],
    },
  },

  {
    path: 'leave-types',
    component: LeaveTypes,
    canActivate: [authGuard],
  },

  {
    path: 'access-denied',
    component: AccessDenied,
  },

  {
    path: '**',
    component: PageNotFound,
  },
];
