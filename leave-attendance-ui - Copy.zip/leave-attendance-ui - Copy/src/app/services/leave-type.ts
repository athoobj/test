import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';
import { LeaveType } from '../models/leave-type';

@Injectable({
  providedIn: 'root',
})
export class LeaveTypeService {
  private readonly apiUrl = `${environment.apiBaseUrl}/leave-types`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<LeaveType[]> {
    return this.http.get<LeaveType[]>(this.apiUrl);
  }

  getById(id: number): Observable<LeaveType> {
    return this.http.get<LeaveType>(`${this.apiUrl}/${id}`);
  }

  create(leaveType: LeaveType): Observable<LeaveType> {
    return this.http.post<LeaveType>(this.apiUrl, leaveType);
  }

  update(id: number, leaveType: LeaveType): Observable<LeaveType> {
    return this.http.put<LeaveType>(`${this.apiUrl}/${id}`, leaveType);
  }

  delete(id: number): Observable<string> {
    return this.http.delete(`${this.apiUrl}/${id}`, {
      responseType: 'text',
    });
  }
}
