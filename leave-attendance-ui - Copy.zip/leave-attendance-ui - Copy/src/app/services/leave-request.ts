import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpParams
} from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';

import {
  LeaveRequest,
  LeaveStatus
} from '../models/leave-request';

import { LeaveRequestCreate } from '../models/leave-request-create';
import { LeaveRequestUpdate } from '../models/leave-request-update';
import { Page } from '../models/pages';

@Injectable({
  providedIn: 'root'
})
export class LeaveRequestService {

  private readonly apiUrl =
    `${environment.apiBaseUrl}/leave-requests`;

  constructor(private http: HttpClient) {}

  search(
    keyword: string,
    status: LeaveStatus | '',
    employeeId: number | null,
    page: number,
    size: number,
    sortBy: string,
    direction: string
  ): Observable<Page<LeaveRequest>> {

    let params = new HttpParams()
      .set('page', page)
      .set('size', size)
      .set('sortBy', sortBy)
      .set('direction', direction);

    if (keyword.trim()) {
      params = params.set(
        'keyword',
        keyword.trim()
      );
    }

    if (status) {
      params = params.set(
        'status',
        status
      );
    }

    if (employeeId !== null) {
      params = params.set(
        'employeeId',
        employeeId
      );
    }

    return this.http.get<Page<LeaveRequest>>(
      this.apiUrl,
      { params }
    );
  }

  getById(
    id: number
  ): Observable<LeaveRequest> {

    return this.http.get<LeaveRequest>(
      `${this.apiUrl}/${id}`
    );
  }

  create(
    request: LeaveRequestCreate
  ): Observable<LeaveRequest> {

    const params = new HttpParams()
      .set('employeeId', request.employeeId)
      .set('leaveTypeId', request.leaveTypeId);

    const body = {
      startDate: request.startDate,
      endDate: request.endDate,
      reason: request.reason
    };

    return this.http.post<LeaveRequest>(
      this.apiUrl,
      body,
      { params }
    );
  }

  update(
    id: number,
    request: LeaveRequestUpdate
  ): Observable<LeaveRequest> {

    const params = new HttpParams()
      .set('employeeId', request.employeeId)
      .set('leaveTypeId', request.leaveTypeId);

    const body = {
      startDate: request.startDate,
      endDate: request.endDate,
      reason: request.reason
    };

    return this.http.put<LeaveRequest>(
      `${this.apiUrl}/${id}`,
      body,
      { params }
    );
  }

  approve(
    id: number
  ): Observable<LeaveRequest> {

    return this.http.put<LeaveRequest>(
      `${this.apiUrl}/${id}/approve`,
      {}
    );
  }

  reject(
    id: number
  ): Observable<LeaveRequest> {

    return this.http.put<LeaveRequest>(
      `${this.apiUrl}/${id}/reject`,
      {}
    );
  }

  cancel(
    id: number
  ): Observable<LeaveRequest> {

    return this.http.put<LeaveRequest>(
      `${this.apiUrl}/${id}/cancel`,
      {}
    );
  }

  delete(
    id: number
  ): Observable<string> {

    return this.http.delete(
      `${this.apiUrl}/${id}`,
      {
        responseType: 'text'
      }
    );
  }
}
