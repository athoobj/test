import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';

import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { FormsModule } from '@angular/forms';

import { LeaveRequestService } from '../../services/leave-request';

import { EmployeeService } from '../../services/employee';

import { AuthService } from '../../services/auth';

import { LeaveRequest, LeaveStatus } from '../../models/leave-request';

import { Employee } from '../../models/employee';

import { Search } from '../../shared/search/search';

import { FilterMenu } from '../../shared/filter-menu/filter-menu';

@Component({
  selector: 'app-leave-requests',
  imports: [CommonModule, RouterLink, FormsModule, Search, FilterMenu],
  templateUrl: './leave-requests.html',
  styleUrl: './leave-requests.css',
})
export class LeaveRequests implements OnInit {
  private leaveRequestService = inject(LeaveRequestService);

  private employeeService = inject(EmployeeService);

  public authService = inject(AuthService);

  private cdr = inject(ChangeDetectorRef);

  private route = inject(ActivatedRoute);

  private router = inject(Router);

  leaveRequests: LeaveRequest[] = [];

  employees: Employee[] = [];

  loading = true;

  errorMessage = '';

  successMessage = '';

  keyword = '';

  statusFilter: LeaveStatus | '' = '';

  employeeIdFilter: number | null = null;

  currentPage = 0;

  pageSize = 5;

  pageSizeOptions = [5, 10, 20];

  totalElements = 0;

  totalPages = 0;

  sortBy = 'id';

  sortDirection: 'asc' | 'desc' = 'asc';

  ngOnInit(): void {
    if (this.canViewAllEmployees()) {
      this.loadEmployees();
    }

    this.route.paramMap.subscribe((params) => {
      const keyword = params.get('keyword');

      const filterValue = params.get('value');

      if (keyword !== null) {
        this.keyword = keyword;

        this.statusFilter = '';
      } else if (filterValue !== null && this.isLeaveStatus(filterValue)) {
        this.statusFilter = filterValue;

        this.keyword = '';
      }

      this.currentPage = 0;

      this.loadLeaveRequests();
    });
  }

  private isLeaveStatus(value: string): value is LeaveStatus {
    return ['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'].includes(value);
  }

  loadLeaveRequests(): void {
    this.loading = true;

    this.errorMessage = '';

    this.leaveRequestService
      .search(
        this.keyword,
        this.statusFilter,
        this.employeeIdFilter,
        this.currentPage,
        this.pageSize,
        this.sortBy,
        this.sortDirection,
      )
      .subscribe({
        next: (data) => {
          this.leaveRequests = data.content;

          this.currentPage = data.number;

          this.totalElements = data.totalElements;

          this.totalPages = data.totalPages;

          this.loading = false;

          this.cdr.detectChanges();
        },

        error: (error) => {
          this.errorMessage = error?.error?.message ?? 'Could not load leave requests.';

          this.loading = false;

          this.cdr.detectChanges();
        },
      });
  }

  private loadEmployees(): void {
    this.employeeService.getAll().subscribe({
      next: (data) => {
        this.employees = data;

        this.cdr.detectChanges();
      },

      error: () => {
        this.employees = [];

        this.cdr.detectChanges();
      },
    });
  }

  onKeywordSearch(keyword: string): void {
    this.currentPage = 0;

    if (keyword) {
      this.router.navigate(['/leave-requests/search', keyword]);
    } else {
      this.keyword = '';

      this.router.navigate(['/leave-requests']);
    }
  }

  onStatusFilterChange(status: LeaveStatus | ''): void {
    this.currentPage = 0;

    if (status) {
      this.router.navigate(['/leave-requests/filter', status]);
    } else {
      this.statusFilter = '';

      this.router.navigate(['/leave-requests']);
    }
  }

  onEmployeeFilterChange(employeeId: number | null): void {
    this.employeeIdFilter = employeeId;

    this.currentPage = 0;

    this.loadLeaveRequests();
  }

  onPageSizeChange(): void {
    this.currentPage = 0;

    this.loadLeaveRequests();
  }

  sortByColumn(column: string): void {
    if (this.sortBy === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortBy = column;

      this.sortDirection = 'asc';
    }

    this.currentPage = 0;

    this.loadLeaveRequests();
  }

  previousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;

      this.loadLeaveRequests();
    }
  }

  nextPage(): void {
    if (this.currentPage + 1 < this.totalPages) {
      this.currentPage++;

      this.loadLeaveRequests();
    }
  }

  canViewAllEmployees(): boolean {
    const role = this.authService.getRole();

    return role === 'HR' || role === 'ADMIN';
  }

  canDelete(): boolean {
    return this.authService.getRole() === 'ADMIN';
  }

  canEdit(): boolean {
    const role = this.authService.getRole();

    return role === 'HR' || role === 'ADMIN';
  }

  deleteLeaveRequest(id?: number): void {
    if (!id || !this.canDelete()) {
      return;
    }

    const confirmed = window.confirm('Are you sure you want to delete this leave request?');

    if (!confirmed) {
      return;
    }

    this.leaveRequestService.delete(id).subscribe({
      next: () => {
        this.successMessage = 'Leave request deleted successfully.';

        this.loadLeaveRequests();
      },

      error: (error) => {
        this.errorMessage = error?.error?.message ?? 'Could not delete leave request.';

        this.cdr.detectChanges();
      },
    });
  }
}
