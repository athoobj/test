import {
  ChangeDetectorRef,
  Component,
  OnInit,
  inject
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

import { AttendanceService } from '../../services/attendance';
import { EmployeeService } from '../../services/employee';
import { AuthService } from '../../services/auth';

import {
  Attendance as AttendanceModel
} from '../../models/attendance';

import { Employee } from '../../models/employee';

@Component({
  selector: 'app-attendance',
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './attendance.html',
  styleUrl: './attendance.css'
})
export class Attendance implements OnInit {

  private attendanceService =
    inject(AttendanceService);

  private employeeService =
    inject(EmployeeService);

  public authService =
    inject(AuthService);

  private cdr =
    inject(ChangeDetectorRef);

  attendanceRecords:
    AttendanceModel[] = [];

  employees: Employee[] = [];

  loading = true;

  processing = false;

  errorMessage = '';

  successMessage = '';

  employeeFilter:
    number | null = null;

  dateFilter = '';

  sortBy = 'id';

  sortDirection:
    'asc' | 'desc' = 'asc';

  absentEmployeeId:
    number | null = null;

  absentDate = '';

  ngOnInit(): void {

    this.loadEmployees();

    this.loadAttendance();
  }

  isPrivilegedRole(): boolean {

    const role =
      this.authService.getRole();

    return (
      role === 'HR' ||
      role === 'ADMIN'
    );
  }

  canDelete(): boolean {

    return (
      this.authService.getRole()
      === 'ADMIN'
    );
  }

  loadAttendance(): void {

    this.loading = true;

    this.errorMessage = '';

    const role =
      this.authService.getRole();

    /*
     * EMPLOYEE should see only
     * his/her own attendance records.
     */
    if (role === 'EMPLOYEE') {

      const employeeId =
        this.authService.getEmployeeId();

      if (employeeId === null) {

        this.errorMessage =
          'Employee account is not linked to an employee record.';

        this.loading = false;

        this.cdr.detectChanges();

        return;
      }

      this.attendanceService
        .getByEmployee(employeeId)
        .subscribe({

          next: (data) => {

            this.attendanceRecords =
              this.sortRecords(data);

            this.loading = false;

            this.cdr.detectChanges();
          },

          error: (
            error: HttpErrorResponse
          ) => {

            this.handleLoadError(
              error
            );
          }
        });

      return;
    }

    /*
     * HR / ADMIN:
     * employee filter
     */
    if (
      this.employeeFilter !== null
    ) {

      this.attendanceService
        .getByEmployee(
          this.employeeFilter
        )
        .subscribe({

          next: (data) => {

            this.attendanceRecords =
              this.sortRecords(data);

            this.loading = false;

            this.cdr.detectChanges();
          },

          error: (
            error: HttpErrorResponse
          ) => {

            this.handleLoadError(
              error
            );
          }
        });

      return;
    }

    /*
     * HR / ADMIN:
     * date filter
     */
    if (this.dateFilter) {

      this.attendanceService
        .getByDate(
          this.dateFilter
        )
        .subscribe({

          next: (data) => {

            this.attendanceRecords =
              this.sortRecords(data);

            this.loading = false;

            this.cdr.detectChanges();
          },

          error: (
            error: HttpErrorResponse
          ) => {

            this.handleLoadError(
              error
            );
          }
        });

      return;
    }

    /*
     * HR / ADMIN:
     * all attendance records
     */
    this.attendanceService
      .getAll(
        this.sortBy,
        this.sortDirection
      )
      .subscribe({

        next: (data) => {

          this.attendanceRecords =
            data;

          this.loading = false;

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.handleLoadError(
            error
          );
        }
      });
  }

  onEmployeeFilterChange(): void {

    if (
      this.employeeFilter !== null
    ) {
      this.dateFilter = '';
    }

    this.loadAttendance();
  }

  onDateFilterChange(): void {

    if (this.dateFilter) {

      this.employeeFilter =
        null;
    }

    this.loadAttendance();
  }

  clearFilters(): void {

    this.employeeFilter = null;

    this.dateFilter = '';

    this.loadAttendance();
  }

  sortByColumn(
    column: string
  ): void {

    if (
      this.sortBy === column
    ) {

      this.sortDirection =
        this.sortDirection === 'asc'
          ? 'desc'
          : 'asc';

    } else {

      this.sortBy =
        column;

      this.sortDirection =
        'asc';
    }

    this.loadAttendance();
  }

  checkIn(
    employeeId: number
  ): void {

    const currentEmployeeId =
      this.authService.getEmployeeId();

    if (
      this.authService.getRole()
      === 'EMPLOYEE' &&
      currentEmployeeId !== employeeId
    ) {
      return;
    }

    const confirmed =
      window.confirm(
        'Are you sure you want to check in?'
      );

    if (!confirmed) {
      return;
    }

    this.processing = true;

    this.clearMessages();

    this.attendanceService
      .checkIn(employeeId)
      .subscribe({

        next: () => {

          this.processing =
            false;

          this.successMessage =
            'Check-in recorded successfully.';

          this.loadAttendance();

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.handleActionError(
            error
          );
        }
      });
  }

  checkOut(
    employeeId: number
  ): void {

    const currentEmployeeId =
      this.authService.getEmployeeId();

    if (
      this.authService.getRole()
      === 'EMPLOYEE' &&
      currentEmployeeId !== employeeId
    ) {
      return;
    }

    const confirmed =
      window.confirm(
        'Are you sure you want to check out?'
      );

    if (!confirmed) {
      return;
    }

    this.processing = true;

    this.clearMessages();

    this.attendanceService
      .checkOut(employeeId)
      .subscribe({

        next: () => {

          this.processing =
            false;

          this.successMessage =
            'Check-out recorded successfully.';

          this.loadAttendance();

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.handleActionError(
            error
          );
        }
      });
  }

  markAbsent(): void {

    if (
      !this.isPrivilegedRole()
    ) {
      return;
    }

    if (
      this.absentEmployeeId === null ||
      !this.absentDate
    ) {

      this.errorMessage =
        'Employee and date are required to mark absence.';

      this.cdr.detectChanges();

      return;
    }

    const confirmed =
      window.confirm(
        'Are you sure you want to mark this employee absent?'
      );

    if (!confirmed) {
      return;
    }

    this.processing = true;

    this.clearMessages();

    this.attendanceService
      .markAbsent(
        this.absentEmployeeId,
        this.absentDate
      )
      .subscribe({

        next: () => {

          this.processing =
            false;

          this.successMessage =
            'Employee marked absent successfully.';

          this.absentEmployeeId =
            null;

          this.absentDate = '';

          this.loadAttendance();

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.handleActionError(
            error
          );
        }
      });
  }

  deleteAttendance(
    id?: number
  ): void {

    if (
      !id ||
      !this.canDelete()
    ) {
      return;
    }

    const confirmed =
      window.confirm(
        'Are you sure you want to delete this attendance record?'
      );

    if (!confirmed) {
      return;
    }

    this.processing = true;

    this.clearMessages();

    this.attendanceService
      .delete(id)
      .subscribe({

        next: () => {

          this.processing =
            false;

          this.successMessage =
            'Attendance record deleted successfully.';

          this.loadAttendance();

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.handleActionError(
            error
          );
        }
      });
  }

  private loadEmployees(): void {

    if (
      !this.isPrivilegedRole()
    ) {
      return;
    }

    this.employeeService
      .getAll()
      .subscribe({

        next: (data) => {

          this.employees =
            data;

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.errorMessage =
            this.getBackendMessage(
              error,
              'Could not load employees.'
            );

          this.cdr.detectChanges();
        }
      });
  }

  private sortRecords(
    records: AttendanceModel[]
  ): AttendanceModel[] {

    return [...records]
      .sort(
        (
          first,
          second
        ) => {

          const firstValue =
            first[
              this.sortBy as keyof AttendanceModel
              ];

          const secondValue =
            second[
              this.sortBy as keyof AttendanceModel
              ];

          if (
            firstValue ===
            secondValue
          ) {
            return 0;
          }

          const result =
            String(firstValue)
              .localeCompare(
                String(secondValue)
              );

          return (
            this.sortDirection
            === 'asc'
              ? result
              : -result
          );
        }
      );
  }

  private clearMessages(): void {

    this.errorMessage = '';

    this.successMessage = '';
  }

  private handleLoadError(
    error: HttpErrorResponse
  ): void {

    this.loading = false;

    this.errorMessage =
      this.getBackendMessage(
        error,
        'Could not load attendance records.'
      );

    this.cdr.detectChanges();
  }

  private handleActionError(
    error: HttpErrorResponse
  ): void {

    this.processing = false;

    this.errorMessage =
      this.getBackendMessage(
        error,
        'Could not complete attendance action.'
      );

    this.cdr.detectChanges();
  }

  private getBackendMessage(
    error: HttpErrorResponse,
    fallback: string
  ): string {

    const response =
      error.error as {
        message?: string;
      } | null;

    return (
      response?.message ??
      fallback
    );
  }
}
