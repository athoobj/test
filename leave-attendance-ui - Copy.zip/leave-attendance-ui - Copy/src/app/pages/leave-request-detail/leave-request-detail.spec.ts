import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaveRequestDetail } from './leave-request-detail';

describe('LeaveRequestDetail', () => {
  let component: LeaveRequestDetail;
  let fixture: ComponentFixture<LeaveRequestDetail>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LeaveRequestDetail],
    }).compileComponents();

    fixture = TestBed.createComponent(LeaveRequestDetail);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
