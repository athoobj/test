import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';

import { CommonModule } from '@angular/common';

import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { LeaveRequestService } from '../../services/leave-request';

import { AuthService } from '../../services/auth';

import { LeaveRequest } from '../../models/leave-request';

@Component({
  selector: 'app-leave-request-detail',
  imports: [CommonModule, RouterLink],
  templateUrl: './leave-request-detail.html',
  styleUrl: './leave-request-detail.css',
})
export class LeaveRequestDetail implements OnInit {
  private route = inject(ActivatedRoute);

  private router = inject(Router);

  private leaveRequestService = inject(LeaveRequestService);

  public authService = inject(AuthService);

  private cdr = inject(ChangeDetectorRef);

  leaveRequest: LeaveRequest | null = null;

  loading = true;

  deleting = false;

  errorMessage = '';

  successMessage = '';

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      const id = Number(params.get('id'));

      if (!id) {
        this.errorMessage = 'Invalid leave request id.';

        this.loading = false;

        this.cdr.detectChanges();

        return;
      }

      this.loadLeaveRequest(id);
    });
  }

  loadLeaveRequest(id: number): void {
    this.loading = true;

    this.errorMessage = '';

    this.leaveRequestService.getById(id).subscribe({
      next: (data) => {
        this.leaveRequest = data;

        this.loading = false;

        this.cdr.detectChanges();
      },

      error: (error) => {
        this.errorMessage = error?.error?.message ?? 'Could not load leave request.';

        this.loading = false;

        this.cdr.detectChanges();
      },
    });
  }

  canEdit(): boolean {
    const role = this.authService.getRole();

    return role === 'HR' || role === 'ADMIN';
  }

  canDelete(): boolean {
    return this.authService.getRole() === 'ADMIN';
  }

  deleteLeaveRequest(): void {
    if (!this.leaveRequest?.id || !this.canDelete()) {
      return;
    }

    const confirmed = window.confirm('Are you sure you want to delete this leave request?');

    if (!confirmed) {
      return;
    }

    this.deleting = true;

    this.errorMessage = '';

    this.leaveRequestService.delete(this.leaveRequest.id).subscribe({
      next: () => {
        this.deleting = false;

        this.router.navigate(['/leave-requests']);
      },

      error: (error) => {
        this.deleting = false;

        this.errorMessage = error?.error?.message ?? 'Could not delete leave request.';

        this.cdr.detectChanges();
      },
    });
  }
}
