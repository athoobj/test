import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';

import { CommonModule } from '@angular/common';

import { ActivatedRoute, RouterLink } from '@angular/router';

import { HttpErrorResponse } from '@angular/common/http';

import { LeaveRequestService } from '../../services/leave-request';

import { AuthService } from '../../services/auth';

import { LeaveRequest } from '../../models/leave-request';

@Component({
  selector: 'app-leave-request-workflow',
  imports: [CommonModule, RouterLink],
  templateUrl: './leave-request-workflow.html',
  styleUrl: './leave-request-workflow.css',
})
export class LeaveRequestWorkflow implements OnInit {
  private route = inject(ActivatedRoute);

  private leaveRequestService = inject(LeaveRequestService);

  public authService = inject(AuthService);

  private cdr = inject(ChangeDetectorRef);

  leaveRequest: LeaveRequest | null = null;

  loading = true;

  processing = false;

  errorMessage = '';

  successMessage = '';

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      const id = Number(params.get('id'));

      if (!Number.isFinite(id) || id <= 0) {
        this.errorMessage = 'Invalid leave request id.';

        this.loading = false;

        this.cdr.detectChanges();

        return;
      }

      this.loadLeaveRequest(id);
    });
  }

  private loadLeaveRequest(id: number): void {
    this.loading = true;

    this.errorMessage = '';

    this.leaveRequestService.getById(id).subscribe({
      next: (data) => {
        this.leaveRequest = data;

        this.loading = false;

        this.cdr.detectChanges();
      },

      error: (error: HttpErrorResponse) => {
        this.errorMessage = this.getBackendMessage(error, 'Could not load leave request.');

        this.loading = false;

        this.cdr.detectChanges();
      },
    });
  }

  isPrivilegedRole(): boolean {
    const role = this.authService.getRole();

    return role === 'HR' || role === 'ADMIN';
  }

  canApprove(): boolean {
    return this.isPrivilegedRole() && this.leaveRequest?.status === 'PENDING';
  }

  canReject(): boolean {
    return this.isPrivilegedRole() && this.leaveRequest?.status === 'PENDING';
  }

  canCancel(): boolean {
    return this.leaveRequest?.status === 'PENDING';
  }

  approve(): void {
    if (!this.leaveRequest?.id || !this.canApprove()) {
      return;
    }

    const confirmed = window.confirm('Are you sure you want to approve this leave request?');

    if (!confirmed) {
      return;
    }

    this.processing = true;

    this.errorMessage = '';

    this.successMessage = '';

    this.leaveRequestService.approve(this.leaveRequest.id).subscribe({
      next: (updated) => {
        this.leaveRequest = updated;

        this.processing = false;

        this.successMessage = 'Leave request approved successfully.';

        this.cdr.detectChanges();
      },

      error: (error: HttpErrorResponse) => {
        this.handleWorkflowError(error);
      },
    });
  }

  reject(): void {
    if (!this.leaveRequest?.id || !this.canReject()) {
      return;
    }

    const confirmed = window.confirm('Are you sure you want to reject this leave request?');

    if (!confirmed) {
      return;
    }

    this.processing = true;

    this.errorMessage = '';

    this.successMessage = '';

    this.leaveRequestService.reject(this.leaveRequest.id).subscribe({
      next: (updated) => {
        this.leaveRequest = updated;

        this.processing = false;

        this.successMessage = 'Leave request rejected successfully.';

        this.cdr.detectChanges();
      },

      error: (error: HttpErrorResponse) => {
        this.handleWorkflowError(error);
      },
    });
  }

  cancel(): void {
    if (!this.leaveRequest?.id || !this.canCancel()) {
      return;
    }

    const confirmed = window.confirm('Are you sure you want to cancel this leave request?');

    if (!confirmed) {
      return;
    }

    this.processing = true;

    this.errorMessage = '';

    this.successMessage = '';

    this.leaveRequestService.cancel(this.leaveRequest.id).subscribe({
      next: (updated) => {
        this.leaveRequest = updated;

        this.processing = false;

        this.successMessage = 'Leave request cancelled successfully.';

        this.cdr.detectChanges();
      },

      error: (error: HttpErrorResponse) => {
        this.handleWorkflowError(error);
      },
    });
  }

  private handleWorkflowError(error: HttpErrorResponse): void {
    this.processing = false;

    this.errorMessage = this.getBackendMessage(error, 'Could not update leave request status.');

    this.cdr.detectChanges();
  }

  private getBackendMessage(error: HttpErrorResponse, fallback: string): string {
    const response = error.error as {
      message?: string;
    } | null;

    return response?.message ?? fallback;
  }
}
