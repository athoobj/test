import {
  ChangeDetectorRef,
  Component,
  OnInit,
  inject
} from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  ValidationErrors,
  Validators
} from '@angular/forms';

import { HttpErrorResponse } from '@angular/common/http';

import {
  ActivatedRoute,
  Router,
  RouterLink
} from '@angular/router';

import { LeaveRequestService } from '../../services/leave-request';
import { EmployeeService } from '../../services/employee';
import { LeaveTypeService } from '../../services/leave-type';
import { AuthService } from '../../services/auth';

import { Employee } from '../../models/employee';
import { LeaveType } from '../../models/leave-type';

import {
  LeaveRequestCreate
} from '../../models/leave-request-create';

import {
  LeaveRequestUpdate
} from '../../models/leave-request-update';

@Component({
  selector: 'app-leave-request-form',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink
  ],
  templateUrl: './leave-request-form.html',
  styleUrl: './leave-request-form.css'
})
export class LeaveRequestForm implements OnInit {

  private fb = inject(FormBuilder);

  private route = inject(ActivatedRoute);

  private router = inject(Router);

  private leaveRequestService =
    inject(LeaveRequestService);

  private employeeService =
    inject(EmployeeService);

  private leaveTypeService =
    inject(LeaveTypeService);

  public authService =
    inject(AuthService);

  private cdr =
    inject(ChangeDetectorRef);

  form: FormGroup;

  employees: Employee[] = [];

  leaveTypes: LeaveType[] = [];

  isEditMode = false;

  requestId: number | null = null;

  loading = true;

  submitting = false;

  errorMessage = '';

  backendFieldErrors:
    Record<string, string> = {};

  constructor() {

    this.form = this.fb.group(
      {
        employeeId: [
          null,
          Validators.required
        ],

        leaveTypeId: [
          null,
          Validators.required
        ],

        startDate: [
          '',
          Validators.required
        ],

        endDate: [
          '',
          Validators.required
        ],

        reason: [
          '',
          Validators.maxLength(500)
        ]
      },
      {
        validators:
        this.dateRangeValidator
      }
    );
  }

  ngOnInit(): void {

    this.prepareEmployee();

    this.loadLeaveTypes();

    this.route.paramMap.subscribe(
      params => {

        const id =
          params.get('id');

        if (id !== null) {

          const parsedId =
            Number(id);

          if (
            !Number.isFinite(parsedId) ||
            parsedId <= 0
          ) {

            this.errorMessage =
              'Invalid leave request id.';

            this.loading = false;

            this.cdr.detectChanges();

            return;
          }

          this.isEditMode = true;

          this.requestId =
            parsedId;

          this.loadLeaveRequest(
            parsedId
          );

        } else {

          this.isEditMode = false;

          this.requestId = null;

          this.loading = false;

          this.cdr.detectChanges();
        }
      }
    );
  }

  isPrivilegedRole(): boolean {

    const role =
      this.authService.getRole();

    return (
      role === 'HR' ||
      role === 'ADMIN'
    );
  }

  private prepareEmployee(): void {

    if (this.isPrivilegedRole()) {

      this.loadEmployees();

      return;
    }

    const employeeId =
      this.authService.getEmployeeId();

    if (employeeId === null) {

      this.errorMessage =
        'Employee account is not linked to an employee record.';

      this.cdr.detectChanges();

      return;
    }

    this.form.patchValue({
      employeeId: employeeId
    });
  }

  private loadEmployees(): void {

    this.employeeService
      .getAll()
      .subscribe({

        next: (
          data: Employee[]
        ) => {

          this.employees =
            data;

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.errorMessage =
            this.getBackendMessage(
              error,
              'Could not load employees.'
            );

          this.cdr.detectChanges();
        }
      });
  }

  private loadLeaveTypes(): void {

    this.leaveTypeService
      .getAll()
      .subscribe({

        next: (
          data: LeaveType[]
        ) => {

          this.leaveTypes =
            data;

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.errorMessage =
            this.getBackendMessage(
              error,
              'Could not load leave types.'
            );

          this.cdr.detectChanges();
        }
      });
  }

  private loadLeaveRequest(
    id: number
  ): void {

    this.loading = true;

    this.errorMessage = '';

    this.leaveRequestService
      .getById(id)
      .subscribe({

        next: (request) => {

          this.form.patchValue({
            employeeId:
            request.employee.id,

            leaveTypeId:
            request.leaveType.id,

            startDate:
            request.startDate,

            endDate:
            request.endDate,

            reason:
              request.reason ?? ''
          });

          this.loading = false;

          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.errorMessage =
            this.getBackendMessage(
              error,
              'Could not load leave request.'
            );

          this.loading = false;

          this.cdr.detectChanges();
        }
      });
  }

  submit(): void {

    this.backendFieldErrors = {};

    this.errorMessage = '';

    if (this.form.invalid) {

      this.form.markAllAsTouched();

      this.cdr.detectChanges();

      return;
    }

    this.submitting = true;

    const value =
      this.form.getRawValue();

    const reasonValue =
      typeof value.reason === 'string'
        ? value.reason.trim()
        : '';

    if (
      this.isEditMode &&
      this.requestId !== null
    ) {

      const request:
        LeaveRequestUpdate = {

        employeeId:
          Number(value.employeeId),

        leaveTypeId:
          Number(value.leaveTypeId),

        startDate:
        value.startDate,

        endDate:
        value.endDate,

        reason:
        reasonValue
      };

      this.leaveRequestService
        .update(
          this.requestId,
          request
        )
        .subscribe({

          next: (updated) => {

            this.submitting =
              false;

            this.router.navigate([
              '/leave-requests/detail',
              updated.id
            ]);
          },

          error: (
            error: HttpErrorResponse
          ) => {

            this.handleBackendError(
              error
            );
          }
        });

      return;
    }

    const request:
      LeaveRequestCreate = {

      employeeId:
        Number(value.employeeId),

      leaveTypeId:
        Number(value.leaveTypeId),

      startDate:
      value.startDate,

      endDate:
      value.endDate,

      reason:
      reasonValue
    };

    this.leaveRequestService
      .create(request)
      .subscribe({

        next: (created) => {

          this.submitting =
            false;

          this.router.navigate([
            '/leave-requests/detail',
            created.id
          ]);
        },

        error: (
          error: HttpErrorResponse
        ) => {

          this.handleBackendError(
            error
          );
        }
      });
  }

  private handleBackendError(
    error: HttpErrorResponse
  ): void {

    this.submitting = false;

    const response =
      error.error as {
        message?: string;
        validationErrors?: Record<string, string>;
      } | null;

    if (
      error.status === 400 &&
      response?.validationErrors
    ) {

      this.backendFieldErrors =
        response.validationErrors;

    } else {

      this.errorMessage =
        response?.message ??
        'Could not save leave request.';
    }

    this.cdr.detectChanges();
  }

  private getBackendMessage(
    error: HttpErrorResponse,
    fallback: string
  ): string {

    const response =
      error.error as {
        message?: string;
      } | null;

    return (
      response?.message ??
      fallback
    );
  }

  private dateRangeValidator(
    group: AbstractControl
  ): ValidationErrors | null {

    const startDate =
      group.get(
        'startDate'
      )?.value;

    const endDate =
      group.get(
        'endDate'
      )?.value;

    if (
      !startDate ||
      !endDate
    ) {

      return null;
    }

    if (
      new Date(endDate) <
      new Date(startDate)
    ) {

      return {
        dateRange: true
      };
    }

    return null;
  }
}
