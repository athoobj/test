export interface AttendanceByEmployeeReport {
  [employeeName: string]: number;
}
