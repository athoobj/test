export interface PersonalSummary {
  myLeaveRequests: number;
  myPendingLeaveRequests: number;
  myApprovedLeaveRequests: number;
  myRejectedLeaveRequests: number;
  myCancelledLeaveRequests: number;
  myAttendanceRecords: number;
}
