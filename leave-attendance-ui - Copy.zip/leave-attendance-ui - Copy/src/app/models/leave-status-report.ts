export interface LeaveStatusReport {
  PENDING: number;
  APPROVED: number;
  REJECTED: number;
  CANCELLED: number;
}
