export interface SystemSummary {
  totalEmployees: number;
  totalLeaveRequests: number;
  pendingLeaveRequests: number;
  approvedLeaveRequests: number;
  rejectedLeaveRequests: number;
  cancelledLeaveRequests: number;
  totalAttendanceRecords: number;
}
