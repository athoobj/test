package com.ejada.eventmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
