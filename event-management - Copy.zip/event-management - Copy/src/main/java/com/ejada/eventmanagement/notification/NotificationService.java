package com.ejada.eventmanagement.notification;

public interface NotificationService {

    void sendNotification(String message);
}
