package com.ejada.eventmanagement.service;

import com.ejada.eventmanagement.entity.Event;
import com.ejada.eventmanagement.exception.ResourceNotFoundException;
import com.ejada.eventmanagement.notification.NotificationService;
import com.ejada.eventmanagement.repository.EventRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {

    private final EventRepository eventRepository;
    private final NotificationService notificationService;

    public EventService(EventRepository eventRepository,
                        NotificationService notificationService) {
        this.eventRepository = eventRepository;
        this.notificationService = notificationService;
    }

    public List<Event> getAllEvents(String sortBy, String direction) {

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        return eventRepository.findAll(sort);
    }

    public Event getEventById(Long id) {

        return eventRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Event not found with id: " + id));
    }

    public List<Event> getEventsByCategory(String category) {
        return eventRepository.findByCategory(category);
    }

    public Event createEvent(Event event) {

        Event savedEvent = eventRepository.save(event);

        notificationService.sendNotification(
                "New event created: " + savedEvent.getTitle());

        return savedEvent;
    }

    public Event updateEvent(Long id, Event updatedEvent) {

        Event event = getEventById(id);

        event.setTitle(updatedEvent.getTitle());
        event.setLocation(updatedEvent.getLocation());
        event.setDate(updatedEvent.getDate());
        event.setCategory(updatedEvent.getCategory());
        event.setCapacity(updatedEvent.getCapacity());
        event.setLevel(updatedEvent.getLevel());
        event.setCode(updatedEvent.getCode());
        event.setActive(updatedEvent.isActive());

        return eventRepository.save(event);
    }

    public Event patchEvent(Long id, Event updatedEvent) {

        Event event = getEventById(id);

        if (updatedEvent.getTitle() != null)
            event.setTitle(updatedEvent.getTitle());

        if (updatedEvent.getLocation() != null)
            event.setLocation(updatedEvent.getLocation());

        if (updatedEvent.getDate() != null)
            event.setDate(updatedEvent.getDate());

        if (updatedEvent.getCategory() != null)
            event.setCategory(updatedEvent.getCategory());

        if (updatedEvent.getCapacity() != 0)
            event.setCapacity(updatedEvent.getCapacity());

        if (updatedEvent.getLevel() != 0)
            event.setLevel(updatedEvent.getLevel());

        if (updatedEvent.getCode() != null)
            event.setCode(updatedEvent.getCode());

        event.setActive(updatedEvent.isActive());

        return eventRepository.save(event);
    }

    public void deleteEvent(Long id) {

        Event event = getEventById(id);

        eventRepository.delete(event);
    }
}