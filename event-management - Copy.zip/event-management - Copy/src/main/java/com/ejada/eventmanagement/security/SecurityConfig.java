package com.ejada.eventmanagement.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http
                .csrf(csrf -> csrf.disable())

                .authorizeHttpRequests(auth -> auth

                        // Swagger and Actuator
                        .requestMatchers(
                                "/swagger-ui.html",
                                "/swagger-ui/**",
                                "/v3/api-docs/**",
                                "/actuator/health",
                                "/actuator/info"
                        ).permitAll()

                        // GET: EMPLOYEE, MANAGER, ADMIN
                        .requestMatchers(HttpMethod.GET, "/events/**")
                        .hasAnyRole("EMPLOYEE", "MANAGER", "ADMIN")

                        // POST: MANAGER, ADMIN
                        .requestMatchers(HttpMethod.POST, "/events/**")
                        .hasAnyRole("MANAGER", "ADMIN")

                        // PUT: MANAGER, ADMIN
                        .requestMatchers(HttpMethod.PUT, "/events/**")
                        .hasAnyRole("MANAGER", "ADMIN")

                        // PATCH: MANAGER, ADMIN
                        .requestMatchers(HttpMethod.PATCH, "/events/**")
                        .hasAnyRole("MANAGER", "ADMIN")

                        // DELETE: ADMIN only
                        .requestMatchers(HttpMethod.DELETE, "/events/**")
                        .hasRole("ADMIN")

                        .anyRequest().authenticated()
                )

                .httpBasic(Customizer.withDefaults());

        return http.build();
    }
}