package com.ejada.eventmanagement.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TrainingConfig {

    @Value("${training.system.name}")
    private String systemName;

    public String getSystemName() {
        return systemName;
    }
}