package com.ejada.eventmanagement.controller;

import com.ejada.eventmanagement.entity.Event;
import com.ejada.eventmanagement.service.EventService;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/events")
public class EventController {

    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping
    public List<Event> getAllEvents(
            @RequestParam(defaultValue = "id") String sort,
            @RequestParam(defaultValue = "asc") String direction) {

        return eventService.getAllEvents(sort, direction);
    }

    @GetMapping("/{id}")
    public Event getEventById(@PathVariable Long id) {
        return eventService.getEventById(id);
    }

    @GetMapping("/category/{category}")
    public List<Event> getByCategory(@PathVariable String category) {
        return eventService.getEventsByCategory(category);
    }

    @PostMapping
    public Object createEvent(@Valid @RequestBody Event event,
                              BindingResult result) {

        if (result.hasErrors()) {
            return result.getAllErrors();
        }

        return eventService.createEvent(event);
    }

    @PutMapping("/{id}")
    public Object updateEvent(@PathVariable Long id,
                              @Valid @RequestBody Event event,
                              BindingResult result) {

        if (result.hasErrors()) {
            return result.getAllErrors();
        }

        return eventService.updateEvent(id, event);
    }

    @PatchMapping("/{id}")
    public Event patchEvent(@PathVariable Long id,
                            @RequestBody Event event) {

        return eventService.patchEvent(id, event);
    }

    @DeleteMapping("/{id}")
    public void deleteEvent(@PathVariable Long id) {
        eventService.deleteEvent(id);
    }
}