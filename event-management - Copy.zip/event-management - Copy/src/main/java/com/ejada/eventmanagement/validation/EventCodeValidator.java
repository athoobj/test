package com.ejada.eventmanagement.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class EventCodeValidator
        implements ConstraintValidator<EventCode, String> {

    @Override
    public boolean isValid(String value,
                           ConstraintValidatorContext context) {

        if (value == null) {
            return false;
        }

        return value.matches("^EVT-\\d{3}$");
    }
}