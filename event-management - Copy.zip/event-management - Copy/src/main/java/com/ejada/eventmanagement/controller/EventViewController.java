package com.ejada.eventmanagement.controller;

import com.ejada.eventmanagement.config.TrainingConfig;
import com.ejada.eventmanagement.entity.Event;
import com.ejada.eventmanagement.service.EventService;
import jakarta.validation.Valid;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

@Controller
public class EventViewController {

    private final EventService eventService;
    private final TrainingConfig trainingConfig;

    public EventViewController(EventService eventService,
                               TrainingConfig trainingConfig) {
        this.eventService = eventService;
        this.trainingConfig = trainingConfig;
    }

    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        StringTrimmerEditor stringTrimmerEditor =
                new StringTrimmerEditor(true);

        dataBinder.registerCustomEditor(
                String.class,
                stringTrimmerEditor
        );
    }

    @GetMapping("/")
    public String home(Model model) {

        model.addAttribute(
                "systemName",
                trainingConfig.getSystemName()
        );

        model.addAttribute(
                "events",
                eventService.getAllEvents("id", "asc")
        );

        return "index";
    }

    @GetMapping("/add")
    public String showForm(Model model) {

        model.addAttribute("event", new Event());

        return "add-event";
    }

    @PostMapping("/save")
    public String saveEvent(
            @Valid @ModelAttribute("event") Event event,
            BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            return "add-event";
        }

        eventService.createEvent(event);

        return "redirect:/";
    }
}