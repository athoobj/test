package com.ejada.eventmanagement.security;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initUsers(AppUserRepository repository,
                                org.springframework.security.crypto.password.PasswordEncoder encoder) {

        return args -> {

            if (repository.findByUsername("employee").isEmpty()) {
                repository.save(new AppUser(
                        "employee",
                        encoder.encode("employee123"),
                        "EMPLOYEE",
                        true
                ));
            }

            if (repository.findByUsername("manager").isEmpty()) {
                repository.save(new AppUser(
                        "manager",
                        encoder.encode("manager123"),
                        "MANAGER",
                        true
                ));
            }

            if (repository.findByUsername("admin").isEmpty()) {
                repository.save(new AppUser(
                        "admin",
                        encoder.encode("admin123"),
                        "ADMIN",
                        true
                ));
            }

        };
    }
}